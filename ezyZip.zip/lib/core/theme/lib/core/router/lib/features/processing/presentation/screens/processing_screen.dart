import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:pixelforge_ai/core/theme/app_theme.dart';

class ProcessingScreen extends ConsumerStatefulWidget {
  final String imageId;
  const ProcessingScreen({super.key, required this.imageId});

  @override
  ConsumerState<ProcessingScreen> createState() => _ProcessingScreenState();
}

class _ProcessingScreenState extends ConsumerState<ProcessingScreen>
    with TickerProviderStateMixin {

  late AnimationController _neuronController;

  final List<String> _stages = [
    "Analyzing Image Details",
    "Building AI Model",
    "Enhancing Resolution",
    "Recovering Textures",
    "Generating 4K Output",
  ];

  int _currentStage = 0;

  @override
  void initState() {
    super.initState();
    _neuronController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat();

    // ✅ Fix: advance stages on a timer so UI actually progresses
    _advanceStages();
  }

  Future<void> _advanceStages() async {
    for (int i = 1; i < _stages.length; i++) {
      await Future.delayed(const Duration(seconds: 3));
      if (mounted) setState(() => _currentStage = i);
    }
  }

  @override
  void dispose() {
    _neuronController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: Column(
          children: [
            const Spacer(),
            // AI Visualization
            Center(
              child: SizedBox(
                width: 250,
                height: 250,
                child: AnimatedBuilder(
                  animation: _neuronController,
                  builder: (context, child) {
                    return CustomPaint(
                      // ✅ Fix: NeuralNetworkPainter defined below
                      painter: NeuralNetworkPainter(
                        progress: _neuronController.value,
                      ),
                      size: const Size(250, 250),
                    );
                  },
                ),
              ),
            )
                .animate(onPlay: (c) => c.repeat())
                .shimmer(
                  duration: 2.seconds,
                  color: AppTheme.secondary.withOpacity(0.1),
                ),
            const SizedBox(height: 40),
            // Status Text
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 400),
              child: Text(
                _stages[_currentStage],
                key: ValueKey(_currentStage),
                style: const TextStyle(
                  color: AppTheme.text,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 16),
            // ✅ Fix: progress tied to current stage
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: LinearProgressIndicator(
                value: (_currentStage + 1) / _stages.length,
                backgroundColor: AppTheme.surface,
                valueColor: const AlwaysStoppedAnimation(AppTheme.primary),
              ),
            ),
            const Spacer(),
            // Info Footer
            Container(
              padding: const EdgeInsets.all(20),
              margin: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppTheme.surface,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildInfoItem("Upscale", "4X"),
                  _buildInfoItem("Engine", "Real-ESRGAN"),
                  _buildInfoItem("Est. Time", "12s"),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ✅ Fix: was cut off — completed method
  Widget _buildInfoItem(String label, String value) {
    return Column(
      children: [
        Text(label,
            style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
        const SizedBox(height: 4),
        Text(value,
            style: const TextStyle(
              color: AppTheme.primary,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            )),
      ],
    );
  }
}

// ✅ Fix: NeuralNetworkPainter was referenced but never defined
class NeuralNetworkPainter extends CustomPainter {
  final double progress;

  NeuralNetworkPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    final nodePaint = Paint()..style = PaintingStyle.fill;

    final center = Offset(size.width / 2, size.height / 2);
    final random = Random(42); // fixed seed for stable layout

    // Generate node positions in rings
    final List<Offset> nodes = [center];
    for (int ring = 1; ring <= 3; ring++) {
      final count = ring * 5;
      final radius = ring * (size.width / 8);
      for (int i = 0; i < count; i++) {
        final angle = (2 * pi / count) * i + progress * pi * 0.5;
        nodes.add(Offset(
          center.dx + radius * cos(angle),
          center.dy + radius * sin(angle),
        ));
      }
    }

    // Draw edges
    for (int i = 0; i < nodes.length; i++) {
      for (int j = i + 1; j < nodes.length; j++) {
        final dist = (nodes[i] - nodes[j]).distance;
        if (dist < size.width * 0.35) {
          final opacity = (1 - dist / (size.width * 0.35)) *
              (0.4 + 0.4 * sin(progress * 2 * pi + i.toDouble()));
          paint.color = AppTheme.secondary.withOpacity(opacity.clamp(0, 1));
          canvas.drawLine(nodes[i], nodes[j], paint);
        }
      }
    }

    // Draw nodes
    for (int i = 0; i < nodes.length; i++) {
      final pulse = 0.5 + 0.5 * sin(progress * 2 * pi + i * 0.7);
      final radius = (i == 0 ? 8.0 : 3.5 + 1.5 * pulse);
      nodePaint.color = i == 0
          ? AppTheme.primary.withOpacity(0.9)
          : AppTheme.secondary.withOpacity(0.5 + 0.5 * pulse);
      canvas.drawCircle(nodes[i], radius, nodePaint);
    }
  }

  @override
  bool shouldRepaint(NeuralNetworkPainter oldDelegate) =>
      oldDelegate.progress != progress;
}